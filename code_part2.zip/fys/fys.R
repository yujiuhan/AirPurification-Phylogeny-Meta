# ==============================================================================
# 1. 环境准备与包加载
# ==============================================================================
# 如果没有安装这些包，请取消下面两行的注释并运行
# install.packages("metafor")
# install.packages("ape")

library(metafor)  # 用于 Meta 分析
library(ape)      # 用于处理系统发育树



# ==============================================================================
# 2. 读取数据与系统发育树
# ==============================================================================
# 请确保 PM.csv 和 PM.tre 都在你的 R 工作目录下
# 你可以使用 setwd("你的文件路径") 来设置工作目录

data <- read.csv("./aafys/PM.csv", stringsAsFactors = FALSE)
tree <- read.tree("./aafys/PM.tre")

# 【关键步骤】添加观测级 ID (Observation Level ID)
# 这一列的作用是处理“同一个物种内部的随机变异”
data$obs_id <- 1:nrow(data)

required_vars <- c("es_adj", "var_adj", "species",
                   "ntemperature", "nrh", "nwind", "nconc", "ngreen", "ndistance")
data <- data[complete.cases(data[, required_vars]), ]
# ==============================================================================
# 3. 数据清洗与匹配 (至关重要的一步)
# ==============================================================================

# 3.1 检查物种名格式
# 系统发育树的末端 (tip.label) 通常是 "Genus_species" (中间有下划线)
# 我们需要确保 CSV 中的 species 列也是这个格式
data$species <- gsub(" ", "_", data$species) # 把空格替换为下划线，以防万一

# 3.2 检查数据与树的重叠情况
# 找出 CSV 有但树里没有的物种
missing_in_tree <- setdiff(data$species, tree$tip.label)
# 找出树里有但 CSV 没用到的物种
missing_in_data <- setdiff(tree$tip.label, data$species)

if(length(missing_in_tree) > 0) {
  warning("注意：以下物种在 CSV 中存在，但在进化树中找不到，将被模型自动丢弃：\n", 
          paste(missing_in_tree, collapse = ", "))
}

# 3.3 修剪进化树 (Pruning)
# 为了让模型运行更快且不报错，我们只保留 CSV 中存在的树枝
# compute.brlen用于给可能缺少分支长度的树赋予分支长度（如果你的树已有长度可忽略警告）
if(is.null(tree$edge.length)) tree <- compute.brlen(tree)
tree_pruned <- keep.tip(tree, intersect(tree$tip.label, data$species))

# 3.4 构建系统发育方差-协方差矩阵 (Phylogenetic Variance-Covariance Matrix)
A <- vcv(tree_pruned, corr = TRUE) # corr=TRUE 确保矩阵标准化为相关性矩阵

# ==============================================================================
# 4. 构建系统发育 Meta 回归模型 (PGLMM)
# ==============================================================================

# 检查方差列是否有 0 或 NA (方差为0会导致模型报错，通常需要赋予一个极小值)
if(any(data$var_adj <= 0, na.rm = TRUE)) {
  data$var_adj[data$var_adj <= 0] <- 1e-6 
  warning("检测到方差为 0 或负数，已替换为 1e-6 以避免计算错误。")
}

# 运行核心模型
# yi: 效应量
# V:  方差
# mods: 固定效应 (你的环境协变量)
# random: 随机效应 (这里我们把 species 与进化树矩阵 A 关联起来)
model <- rma.mv(yi = es_adj, 
                V = var_adj, 
                # 这里放入你的环境因素，模型会自动利用同物种的不同环境值来计算回归斜率
                mods = ~ ntemperature + nrh + nwind + nconc + ngreen + ndistance, 
                
                # 【关键修改】这里变成了 list，包含两个随机效应
                # 1. ~ 1 | species : 告诉模型，同物种的行，共享相同的“遗传本底”
                # 2. ~ 1 | obs_id  : 告诉模型，剩下的差异是“这一次观测特有的噪音”
                random = list(~ 1 | species, ~ 1 | obs_id), 
                
                R = list(species = A), # 依然关联进化树
                data = data,
                method = "REML") # 限制性最大似然法

# ==============================================================================
# 5. 结果输出与解读
# ==============================================================================

print(summary(model))

# --- 关键结果解读指南 ---

# 1. 固定效应 (Fixed Effects):
#    查看 pval 列。
#    如果 nconc (浓度) 的 pval < 0.05，说明环境浓度显著影响净化效果。
#    如果这些协变量都显著，说明你成功剥离了环境噪音。

# 2. 系统发育信号 (Phylogenetic Signal):
#    查看 sigma^2 (Estimated amount of residual heterogeneity).
#    虽然 rma.mv 不直接给出 Lambda 值，但 sigma^2 代表了归因于“物种差异”的变异。
#    为了量化系统发育信号到底有多强，我们可以计算“系统发育遗传力 (Phylogenetic Heritability, H2)”：

# 计算总变异 (近似)
W <- diag(1/data$var_adj)
n <- nrow(data)
total_variance <- sum(model$sigma2) + (n-1)/sum(diag(W)) # 这是一个简化估算
phylo_signal <- model$sigma2 / total_variance

cat("\n==============================================\n")
cat("系统发育信号强度 (粗略估计): ", round(phylo_signal, 4), "\n")
cat("如果此值接近 1，说明净化能力高度受进化关系控制；\n")
cat("如果接近 0，说明净化能力主要受环境或随机因素影响。\n")
cat("==============================================\n")

# ==============================================================================
# 6. (可选) 诊断检查：共线性 (VIF)
# ==============================================================================
# 检查你的环境变量是否重叠太多 (例如温度和绿化覆盖可能高度相关)
# 如果 VIF > 5 或 10，可能需要移除某些变量
cat("\n方差膨胀因子 (VIF) 检查:\n")
print(vif(model))


# ==============================================================================
# 7. (修正版) 绘制剥离环境因素后的系统发育信号图
# ==============================================================================

# --- 7.1 加载绘图包 ---
if (!require("BiocManager", quietly = TRUE)) install.packages("BiocManager")
if (!require("ggtree")) BiocManager::install("ggtree")
if (!require("ggplot2")) install.packages("ggplot2")
if (!require("viridis")) install.packages("viridis")

library(ggtree)
library(ggplot2)
library(viridis)

# --- 7.2 提取“纯净”的系统发育效应 (BLUPs) ---
blups <- ranef(model)
phylo_effects <- blups$species
used_species <- rownames(phylo_effects)
tree_for_plot <- keep.tip(tree_pruned, used_species)
# 【错误修正点】: 查看 phylo_effects 的列名，通常是 'intrcpt' 而不是 'pred'
# 我们可以加一行打印列名，确保万无一失
print(colnames(phylo_effects)) 

plot_data <- data.frame(
  Species = rownames(phylo_effects),
  # 修改这里：使用 intrcpt 列 (代表 Random Intercept 的偏差值)
  Phylo_Signal = phylo_effects$intrcpt 
)
rownames(plot_data) <- plot_data$Species

# 只保留数值列用于画热图
plot_data_value <- plot_data[, "Phylo_Signal", drop = FALSE]

# --- 7.3 绘制进化树 ---
# layout = "rectangular" : 矩形布局，最适合展示对比
p_tree <- ggtree(tree_for_plot, layout = "rectangular", ladderize = TRUE, size = 0.6) +
  # 添加比例尺
  geom_treescale(x = 0, y = 0, width = NULL, offset = 1) +
  # 添加物种名 (斜体)
  geom_tiplab(size = 3, align = TRUE, linesize = 0.3, offset = 0.5, fontface = "italic") +
  # 调整显示范围，给右侧热图留出空间
  xlim(0, max(node.depth.edgelength(tree_pruned)) * 1.6)

# --- 7.4 添加热图 (修正配色逻辑版) ---
# offset 根据树大小微调
offset_val <- max(node.depth.edgelength(tree_pruned)) * 0.35

p_combined <- gheatmap(p_tree, 
                       plot_data_value, 
                       offset = offset_val, 
                       width = 0.1, 
                       colnames = FALSE, 
                       color = "white") + 
  # 【关键修改】配色方案
  # 因为数据越负越好，所以 low (负端) 设为代表"好"的颜色 (如绿色)
  # high (正端) 设为代表"差"的颜色 (如褐色或红色)
  scale_fill_gradient2(
    low = "#006d2c",   # 强净化 (Negative BLUP) -> 深绿
    mid = "#f7f7f7",   # 平均水平 -> 浅灰
    high = "#8c510a",  # 弱净化 (Positive BLUP) -> 褐色/红色
    na.value = "grey92",
    midpoint = 0, 
    #limits = c(-0.01, 0.01), 
    name = "Intrinsic Effect\n(BLUP)" # 图例名注明方向
  ) +
  theme(
    legend.position = "left",
    legend.title = element_text(size = 8, face = "bold"),
    legend.text = element_text(size = 7)
  ) +
  labs(title = "Intrinsic PM Purification Ability (Environment Removed)")



# --- 7.5 导出结果 ---
if (!dir.exists("fig2")) dir.create("fig2")

# 保存为 PDF (矢量图)
ggsave(filename = "fig2/PM_Phylo_Signal_BLUPs.pdf", plot = p_combined, 
       width = 8, height = max(6, nrow(plot_data)*0.2))

# 保存为 TIFF (高DPI)
ggsave(filename = "fig2/PM_Phylo_Signal_BLUPs.tiff", plot = p_combined, 
       width = 8, height = max(6, nrow(plot_data)*0.2), 
       dpi = 1200, compression = "lzw")

print("绘图完成！图表展示的是剔除环境因子后的物种内禀差异。")
print(p_combined)

# ==============================================================================
# 8. 基于 BLUPs 计算 Blomberg's K 和 Pagel's Lambda
# ==============================================================================

# 安装并加载 phytools 包 (用于计算 K 和 Lambda 的标准包)
if (!require("phytools", quietly = TRUE)) install.packages("phytools")
library(phytools)

cat("\n==============================================\n")
cat("准备计算 Blomberg's K 和 Pagel's Lambda...\n")

# 1. 准备数据格式：phytools 需要一个“命名向量” (Named Vector)
# 我们使用你之前在第 7 步提取好的内禀效应值 (BLUPs)
trait_blups <- phylo_effects$intrcpt
names(trait_blups) <- rownames(phylo_effects)

# 确保树的末端节点和命名向量完全匹配 (按理说你在第 3 步修剪后已经是匹配的了)
# 为了安全起见，再次检查
common_species <- intersect(tree_pruned$tip.label, names(trait_blups))
tree_for_sig <- keep.tip(tree_pruned, common_species)
trait_for_sig <- trait_blups[tree_for_sig$tip.label]

# 2. 计算 Blomberg's K
# test = TRUE 会运行随机化置换检验来给出 p 值
cat("\n--- 计算 Blomberg's K ---\n")
K_result <- phylosig(tree_for_sig, trait_for_sig, method = "K", test = TRUE, nsim = 1000)
print(K_result)

# 3. 计算 Pagel's Lambda
# test = TRUE 会进行似然比检验 (Likelihood Ratio Test) 来给出 p 值
cat("\n--- 计算 Pagel's Lambda ---\n")
Lambda_result <- phylosig(tree_for_sig, trait_for_sig, method = "lambda", test = TRUE)
print(Lambda_result)

cat("==============================================\n")