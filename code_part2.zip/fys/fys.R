
# 载入必要的R包
library(ape)
library(brms)
library(tidyverse)
library(phytools)
library(ggtree)
library(geiger)




# 1. 数据准备阶段
# 1.1 物种名称标准化
es_regdiv_nox <- es_regdiv %>%
  filter(p_type1 == "NOX") %>%
  mutate(species = str_replace_all(`dominant species`, " ", "_")) %>%
  dplyr::select(species, es_adj, family, leaf_type, evergreen_forest)

# 增加的代码: 去掉species列值为“0”的所有行
es_regdiv_nox <- es_regdiv_nox %>%
  filter(species != "0")

# 增加的代码：
es_regdiv_nox <- es_regdiv_nox %>%
  group_by(species) %>%
  summarise(
    es_adj = mean(es_adj, na.rm = TRUE),
    family = first(family),
    leaf_type = first(leaf_type),
    evergreen_forest = first(evergreen_forest)
  ) %>%
  ungroup()

# 1.2 效应量数据整理
nox_effect_summary <- es_regdiv_nox %>%
  group_by(species) %>%
  summarise(
    mean_effect = mean(es_adj, na.rm = TRUE),
    sd_effect = sd(es_adj, na.rm = TRUE),
    leaf_type = first(leaf_type),
    forest_type = first(evergreen_forest)
  )

# 2. 系统发育树构建
phylo_tree <- read.tree("./aafys/nox.tre")

# 查看树的tip标签数量和前几个标签
length(phylo_tree$tip.label)
head(phylo_tree$tip.label)

# 查看数据的行数和行名
nrow(es_regdiv_nox)
rownames(es_regdiv_nox)
head(rownames(es_regdiv_nox))

# 设置行名为species列的值
rownames(es_regdiv_nox) <- as.character(es_regdiv_nox$species)

# 移除species列（因为已经作为行名，不再需要该列）
es_regdiv_nox <- es_regdiv_nox[, colnames(es_regdiv_nox) != "species", drop = FALSE]

# 验证新的行名
cat("新的行名前5个:", head(rownames(es_regdiv_nox), 5), "\n")
cat("数据维度:", dim(es_regdiv_nox), "\n")

# 3. 数据整合
# 3.1 匹配系统发育树和效应量数据
matched_species <- intersect(phylo_tree$tip.label, nox_effect_summary$species)
comparative_data <- nox_effect_summary[nox_effect_summary$species %in% matched_species, ]
comparative_data <- comparative_data[match(matched_species, comparative_data$species), ]


# 2. 确保匹配
matched_species <- intersect(phylo_tree$tip.label, nox_effect_summary$species)
comparative_data <- nox_effect_summary[nox_effect_summary$species %in% matched_species, ]

# 3. 设置行名
rownames(comparative_data) <- comparative_data$species


# 4. 系统发育信号检验
# 4.1 Pagel's lambda检验
library(geiger)


# 4.2 系统发育信号可视化
# 创建效应量映射的系统发育树
library(ggtree)
library(ggplot2)

# 绘制系统发育树并映射效应量
p <- ggtree(phylo_tree) +
  geom_tiplab(size = 3, color = "darkblue") +
  theme_tree2()

p2 <- p + 
  geom_tippoint(aes(color = comparative_data$mean_effect), 
                size = 5) +
  scale_color_gradient2(
    low = "blue", 
    mid = "white", 
    high = "red", 
    midpoint = 0,
    name = "NOx Effect Size"
  )

# 5. 结果解释和报告
# 5.1 生成分析报告
report <- list(
  pagel_lambda = pagel_lambda_effect,
  species_data = comparative_data,
  plot = p2
)

# 保存结果
saveRDS(report, "nox_phylogenetic_analysis_report.RDS")
ggsave("nox_phylogenetic_tree.pdf", p2, width = 10, height = 15)

# 打印关键结果
cat("Pagel's Lambda Result:\n")
print(pagel_lambda_effect)